% read image "kku.jpg" into varibale I and get its size
I = imread('images/kku.jpg');
S = size(I);
% use imresize function to scale the image and get 
% image new size
I2 = imresize(I,0.5);

% Stretch the image to 600 x 800 size using imresize


% show both images
