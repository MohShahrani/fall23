% read image "toys1.gif" into variable x

% WHAT will be the range of values of x
% Subtract 255 out of each pixel of x

% PAY ATTENTION to the range of values, is it possible
% to show an image of the same range of values.


% use subplot function to show the original image 
% and the negtive in one figure
figure;
