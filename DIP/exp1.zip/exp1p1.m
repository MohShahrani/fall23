% read kku.jpg image using imread to variable original_image

figure
subplot (3, 1, 1) ;
% show the original_image using imshow function.

title ( ' Original Image ' ) ;

subplot (3, 1, 2) ;
% use rgb2gray to convert image to gray scale image
% assign the result to gray_image then show the image


title ( ' Gray Image ' ) ;

subplot (3, 1, 3) ;
% use im2bw to convert image to black and white image
% assign the result to bw_image



title ( ' Black & White Image ' ) ;


