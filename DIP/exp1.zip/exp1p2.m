% You can create a 3D matrix using ones(x,y,z) or zeros(x,y,z)
% x is the number of rows, y is the number of columns, z is the number
% of dimensions required.
% lets suppose you have a 3D matrix called pixels
% you can access all rows and columns in the Third row
% by writing this code
% pixels(:,:,3)

% Create a 3D matrix called Colored_image using zeros(x,y,z)

% Assign values to first dimension colored_image(:,:,1) = 

% Similarly, for the second dimension colored_image(:,:,2) = 

% Similarly, for the Third dimension colored_image(:,:,3) = 

% use Image() function to show the image. use matlab help if you dont know
% how to use Image() function.

