% read the image mandril_color.tif from the provided image set

% get # rows, columns and, dimentsions

% use function zeros() to create a matrix with rows coloumns similar to the image

% use function uint8() to convert newly created matrix to datatype similar to the original image.
flipped = uint8(flipped);

% create two nested for loops to go over all image pixles 


% inside loops, each pixel should be assigend to its counterpart in the flipped image







% use the function image() to display the flipped image stored in your matrix
